echo read -p 'Arrastre: ' cifrar 
gpg -c $cifrar