#! /bin/bash 
#lo de arriba aclara al sistema que es un sh 
clear 
#clear se usa para limpiar lo que se ha escrito
echo "ıllıllı adмιnιѕтracιon de paqυeтeѕ ıllıllı"
#echo es eco es lo que se mostrara al usuario
echo "1.Limpiar paquetes innecesarios" 
echo "2.Actualizar los paquetes" 
echo "3.Actualizar la version de tu Linux "
echo "4.Borrar todos los archivos .deb inservibles "
echo "5.Aptitude (synaptic version consola)"
echo "6.Chequear dependencias"
echo "7.Reconfigurar dpkg"
echo "8.Saber  cuanto pesa el cache (paquetes de instalación ya usados)"
echo "9.Instalar un programa"
echo "10 desinstalar un programa"
echo "00.Volver al menu principal"

read -p  "Elige:  " opcion 
#Aca le indico que lea los digitos que ponga el user
case $opcion in 
#en caso de elegir una se iniciara ...
1) sudo apt-get clean; sh 1 ;; 
#estas son las opciones 
#Estan sacada de T! y varios foros Que ni me acuerdo :p
2) sudo apt-get upgrade  ;; 
3) sudo apt-get dist-upgrade  ;;
4) sudo apt-get autoclean ;; 
5) sudo aptitude ;;
6) sudo apt-get check ;;
7) sudo dpkg --configure -a ;;
8) clear ;du -bsh /var/cache/apt/ ;echo ;echo ; echo "ese es su peso" ;;
# limpiar cosola encadenamiento preguntar al sist. cuanto pesa 
9) clear 
#NOTA esta basado en esta pagina http://www.taringa.net/posts/linux/16385443/Como-crear-scripts-en-Linux.html
# (por defecto vale “ ”),en este script queremos 
# cambiarlo a “,” para escribir por teclado app 
IFS=“” 
read -p "Introduce el nombre de la aplicacion : " app 
echo "sudo apt-get install $app " > install.sh; echo "ATENCION!!!:a cotinuacion se instalara la app para cacelar Ctrl C ";sleep 2;echo "3";sleep 1;echo "2";sleep 1;echo "1"; sh install.sh ;;
10) clear 
#NOTA esta basado en esta pagina http://www.taringa.net/posts/linux/16385443/Como-crear-scripts-en-Linux.html
# (por defecto vale “ ”),en este script queremos 
# cambiarlo a “,” para escribir por teclado app1,app2
IFS=“” 
read -p "Introduce el nombre de la aplicacion : " app 
#sacado de http://www.ajpdsoft.com/modules.php?name=Foros&file=viewtopic&t=1210
echo "sudo apt-get remove --purge $app;sudo apt-get clean" ;;
00) sh 1 ;;
esac
