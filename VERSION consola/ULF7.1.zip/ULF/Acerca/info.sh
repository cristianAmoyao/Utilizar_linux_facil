#! /bin/bash
clear
echo " U.L.F V. 7.1 Bajo la Licencia GPL 3.0"

echo "agradezco a Alejandro Hernandez Por ayudarme con el otro soft (basado en gambas)"
echo "Agradezco a todos ustedes por usar este sh"
echo "agradezco a T! por enseñarme algunos comandos que desconocia"
echo "Link del Post:"
echo "http://www.taringa.net/posts/linux/16385443/Como-crear-scripts-en-Linux.html"
echo 
echo "99.Volver al Menu"
read -p  "Elige:  " menu
#case $opcion in  
case $menu in
99) sh 1 ;;

esac

