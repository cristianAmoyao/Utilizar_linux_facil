sudo apt-get install chromium-browser 
